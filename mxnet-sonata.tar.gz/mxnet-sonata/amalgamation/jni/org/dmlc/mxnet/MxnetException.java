package org.dmlc.mxnet;

public class MxnetException extends Exception {
  public MxnetException(){}
  public MxnetException(String txt) {
    super(txt);
  }
}

