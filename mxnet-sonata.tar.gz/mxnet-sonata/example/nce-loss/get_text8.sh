mkdir -p ./data/
cd ./data/
wget http://mattmahoney.net/dc/text8.zip
unzip text8.zip
